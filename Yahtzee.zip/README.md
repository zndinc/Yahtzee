# Yahtzee

Simple WPF implementation of Yahtzee. Will eventually have sound and animations. 
